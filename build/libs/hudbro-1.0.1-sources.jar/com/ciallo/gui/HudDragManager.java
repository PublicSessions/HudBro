package com.ciallo.gui;

import com.ciallo.module.hud.AbstractHudModule;
import com.ciallo.module.ModuleManager;
import com.ciallo.gui.HudSettingsScreen;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class HudDragManager {
    private static final HudDragManager INSTANCE = new HudDragManager();
    private AbstractHudModule draggedModule;
    private int dragOffsetX;
    private int dragOffsetY;
    private AbstractHudModule hoveredModule;
    private boolean wasRightDown = false;
    private boolean wasLeftDown = false;
    private static final int SNAP_DISTANCE = 8;

    private HudDragManager() {}

    public static HudDragManager getInstance() {
        return INSTANCE;
    }

    private static long getWindowHandle(class_1041 w) {
        try { return (long) w.getClass().getMethod("handle").invoke(w); }
        catch (Exception e) { try { return (long) w.getClass().getMethod("getHandle").invoke(w); } catch (Exception e2) { return 0; } }
    }

    private static boolean isLeftDown() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) return false;
        long h = getWindowHandle(client.method_22683());
        if (h == 0) return false;
        return GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private static boolean isRightDown() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) return false;
        long h = getWindowHandle(client.method_22683());
        if (h == 0) return false;
        return GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    public void renderHoverHighlight(class_332 context) {
        class_310 client = class_310.method_1551();
        class_1041 window = client.method_22683();
        if (window == null) return;
        double scale = window.method_4495();
        if (scale == 0) scale = 1;
        int mouseX = (int) (client.field_1729.method_1603() / scale);
        int mouseY = (int) (client.field_1729.method_1604() / scale);

        hoveredModule = null;
        List<AbstractHudModule> huds = new ArrayList<>(ModuleManager.INSTANCE.getHudModules());
        for (int i = huds.size() - 1; i >= 0; i--) {
            AbstractHudModule hud = huds.get(i);
            if (!hud.isEnabled()) continue;
            int x = hud.getX();
            int y = hud.getY();
            int w = hud.getWidth();
            int h = hud.getHeight();
            if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                hoveredModule = hud;
                context.method_25294(x, y, x + w, y + h, 0x40FFFFFF);
                context.method_51433(class_310.method_1551().field_1772, hud.getName(), x, y - 10, 0xFFFFFFFF, true);
                break;
            }
        }
    }

    public void update() {
        class_310 client = class_310.method_1551();
        if (client.field_1729 == null || client.field_1724 == null) return;

        class_1041 window = client.method_22683();
        if (window == null) return;
        double scale = window.method_4495();
        if (scale == 0) scale = 1;
        int mouseX = (int) (client.field_1729.method_1603() / scale);
        int mouseY = (int) (client.field_1729.method_1604() / scale);

        boolean leftDown = isLeftDown();
        boolean rightDown = isRightDown();

        if (leftDown && !wasLeftDown && hoveredModule != null && draggedModule == null) {
            draggedModule = hoveredModule;
            dragOffsetX = mouseX - draggedModule.getX();
            dragOffsetY = mouseY - draggedModule.getY();
        }

        if (draggedModule != null) {
            if (leftDown) {
                int newX = mouseX - dragOffsetX;
                int newY = mouseY - dragOffsetY;
                int w = draggedModule.getWidth();
                int h = draggedModule.getHeight();
                int screenWidth = window.method_4486();
                int screenHeight = window.method_4502();
                int centerX = screenWidth / 2;
                int centerY = screenHeight / 2;
                int elemCenterX = newX + w / 2;
                int elemCenterY = newY + h / 2;
                if (Math.abs(elemCenterX - centerX) < SNAP_DISTANCE) {
                    newX = centerX - w / 2;
                }
                if (Math.abs(elemCenterY - centerY) < SNAP_DISTANCE) {
                    newY = centerY - h / 2;
                }
                draggedModule.setPosition(newX, newY);
            } else {
                com.ciallo.config.HudConfig.save();
                draggedModule = null;
            }
        }

        if (rightDown && !wasRightDown && hoveredModule != null) {
            client.method_1507(new HudSettingsScreen(hoveredModule));
        }

        wasLeftDown = leftDown;
        wasRightDown = rightDown;
    }

    public void renderAlignmentLines(class_332 context) {
        if (draggedModule == null) return;
        int screenWidth = context.method_51421();
        int screenHeight = context.method_51443();
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;
        context.method_25294(centerX - 1, 0, centerX + 1, screenHeight, 0x40FFFFFF);
        context.method_25294(0, centerY - 1, screenWidth, centerY + 1, 0x40FFFFFF);
    }
}
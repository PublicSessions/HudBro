package com.ciallo.gui;

import com.ciallo.module.hud.AbstractHudModule;
import com.ciallo.module.ModuleManager;
import com.ciallo.util.MC;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {
    private AbstractHudModule draggedModule;
    private int dragOffsetX;
    private int dragOffsetY;
    private int mouseX;
    private int mouseY;
    private static final int SNAP_DISTANCE = 8;

    public HudEditorScreen() {
        super(class_2561.method_43470("HUD Editor"));
    }

    public static boolean isActive() {
        return MC.client3.field_1755 instanceof HudEditorScreen;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float verticalAmount) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;

        int screenWidth = context.method_51421();
        int screenHeight = context.method_51443();
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        context.method_25294(0, 0, screenWidth, screenHeight, 0x80000000);
        context.method_25294(centerX - 1, 0, centerX + 1, screenHeight, 0x40FFFFFF);
        context.method_25294(0, centerY - 1, screenWidth, centerY + 1, 0x40FFFFFF);

        renderHudElements(context, verticalAmount);
        renderDragPreview(context, mouseX, mouseY, centerX, centerY);

        context.method_27534(MC.client3.field_1772, class_2561.method_43470("HUD Editor - ESC to close - /hudbro"), screenWidth / 2, 10, 0xFFFFFFFF);
    }

    private void renderHudElements(class_332 context, float verticalAmount) {
        List<AbstractHudModule> huds = new ArrayList<>(ModuleManager.INSTANCE.getHudModules());
        for (AbstractHudModule hud : huds) {
            hud.setEditorMode(true);
            hud.render(context, verticalAmount);
        }
    }

    private void renderDragPreview(class_332 context, int mouseX, int mouseY, int centerX, int centerY) {
        List<AbstractHudModule> huds = new ArrayList<>(ModuleManager.INSTANCE.getHudModules());
        for (AbstractHudModule hud : huds) {
            int x = hud.getX();
            int y = hud.getY();
            int w = hud.getWidth();
            int h = hud.getHeight();
            if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                context.method_25294(x, y, x + w, y + h, 0x30FFFFFF);
                context.method_51433(MC.client3.field_1772, hud.getName(), x, y - 10, 0xFFFFFFFF, true);
            }
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        
        
        
        if (button == 0) {
            List<AbstractHudModule> huds = new ArrayList<>(ModuleManager.INSTANCE.getHudModules());
            for (int i = huds.size() - 1; i >= 0; i--) {
                AbstractHudModule hud = huds.get(i);
                int x = hud.getX();
                int y = hud.getY();
                int w = hud.getWidth();
                int h = hud.getHeight();
                if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                    draggedModule = hud;
                    dragOffsetX = (int) mouseX - x;
                    dragOffsetY = (int) mouseY - y;
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggedModule != null) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;

            int w = draggedModule.getWidth();
            int h = draggedModule.getHeight();
            int screenWidth = class_310.method_1551().method_22683().method_4486();
            int screenHeight = class_310.method_1551().method_22683().method_4502();
            int centerX = screenWidth / 2;
            int centerY = screenHeight / 2;

            int elemCenterX = newX + w / 2;
            int elemCenterY = newY + h / 2;

            if (Math.abs(elemCenterX - centerX) < SNAP_DISTANCE) {
                newX = centerX - w / 2;
            }
            if (Math.abs(elemCenterY - centerY) < SNAP_DISTANCE) {
                newY = centerY - h / 2;
            }

            draggedModule.setPosition(newX, newY);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (draggedModule != null) {
            draggedModule = null;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            MC.client3.method_1507(null);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}


package com.ciallo.module.hud;

import com.ciallo.api.Listener3;
import com.ciallo.module.Category;
import com.ciallo.module.Module;
import com.ciallo.setting.NumberSetting;
import com.ciallo.setting.ColorSetting;
import com.ciallo.util.MC;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_332;

public class TotemHud extends AbstractHudModule implements Listener3 {
    private final NumberSetting x = (NumberSetting) this.m28(new NumberSetting("X", 10.0, 0.0, 960.0, 1.0, 1.0));
    private final NumberSetting y = (NumberSetting) this.m28(new NumberSetting("Y", 10.0, 0.0, 463.0, 1.0, 1.0));
    private final NumberSetting scale = (NumberSetting) this.m28(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.1));
    private final ColorSetting color = (ColorSetting) this.m28(new ColorSetting("Color", -1));

    public TotemHud() {
        super("TotemHud", "Displays totem count.", Category.HUD);
        this.setChinese("图腾HUD");
        this.setChineseDescription("显示图腾数量");
    }

    @Override
    public int getX() {
        return x.getInt();
    }

    @Override
    public int getY() {
        return y.getInt();
    }

    @Override
    public int getWidth() {
        return Math.round(16.0f * scale.getFloat());
    }

    @Override
    public int getHeight() {
        return Math.round(24.0f * scale.getFloat());
    }

    @Override
    public void setPosition(int x, int y) {
        this.x.setInt(x);
        this.y.setInt(y);
    }

    @Override
    public void render(class_332 context, float partialTicks) {
        if (MC.client3.field_1724 == null) {
            return;
        }

        int posX = getX();
        int posY = getY();
        int count = getTotemCount();

        context.method_51448().method_22903();
        context.method_51448().method_22904((double)posX, (double)posY, 0.0);
        context.method_51448().method_22905(scale.getFloat(), scale.getFloat(), 1.0f);

        class_1799 totem = new class_1799(class_1802.field_8288, 1);
        context.method_51427(totem, 0, 0);
        context.method_51433(MC.client3.field_1772, Integer.toString(count), 16, 8, color.getColor(), true);

        context.method_51448().method_22909();
    }

    private int getTotemCount() {
        if (MC.client3.field_1724 == null) {
            return 0;
        }

        int count = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 stack = MC.client3.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8288)) {
                count += stack.method_7947();
            }
        }

        class_1799 offHand = MC.client3.field_1724.method_6079();
        if (offHand.method_31574(class_1802.field_8288)) {
            count += offHand.method_7947();
        }

        return count;
    }
}


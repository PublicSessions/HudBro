package com.ciallo.module.hud;

import com.ciallo.api.Listener3;
import com.ciallo.module.Category;
import com.ciallo.module.Module;
import com.ciallo.setting.BooleanSetting;
import com.ciallo.setting.NumberSetting;
import com.ciallo.util.MC;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public class ArmorHud extends AbstractHudModule implements Listener3 {
    private final NumberSetting x = (NumberSetting) this.m28(new NumberSetting("X", 6.0, 0.0, 960.0, 1.0, 1.0));
    private final NumberSetting y = (NumberSetting) this.m28(new NumberSetting("Y", 54.0, 0.0, 463.0, 1.0, 1.0));
    public final BooleanSetting shadow = (BooleanSetting) this.m28(new BooleanSetting("Shadow", true));
    public final BooleanSetting durability = (BooleanSetting) this.m28(new BooleanSetting("Durability", true));
    private final NumberSetting scale = (NumberSetting) this.m28(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.1));

    public ArmorHud() {
        super("ArmorHud", "Shows armor status.", Category.HUD);
        this.setChinese("??HUD");
        this.setChineseDescription("???????");
    }

    @Override
    public int getX() {
        return x.getInt();
    }

    @Override
    public int getY() {
        return y.getInt();
    }

    @Override
    public int getWidth() {
        return Math.round(80.0f * scale.getFloat());
    }

    @Override
    public int getHeight() {
        return Math.round((durability.getValue() ? 28.0f : 16.0f) * scale.getFloat());
    }

    @Override
    public void setPosition(int x, int y) {
        this.x.setInt(x);
        this.y.setInt(y);
    }

    @Override
    public void render(class_332 context, float partialTicks) {
        int posX = getX();
        int posY = getY();

        context.method_51448().method_22903();
        context.method_51448().method_22904((double)posX, (double)posY, 0.0);
        context.method_51448().method_22905(scale.getFloat(), scale.getFloat(), 1.0f);

        if (MC.client3.field_1724 == null) {
            if (isEditorMode()) {
                context.method_25294(0, 0, getWidth(), getHeight(), 1427445792);
                context.method_51433(MC.client3.field_1772, "Armor HUD", 4, 2, -1184275, shadow.getValue());
            }
            context.method_51448().method_22909();
            return;
        }

        int itemX = 0;
        for (int i = 3; i >= 0; i--) {
            class_1799 item = MC.client3.field_1724.method_31548().method_5438(36 + i);
            if (!item.method_7960()) {
                context.method_51427(item, itemX + 2, 0);
                context.method_51432(MC.client3.field_1772, item, itemX + 2, 0, null);
                if (durability.getValue() && item.method_7936() > 0) {
                    int maxDamage = item.method_7936();
                    int damage = item.method_7919();
                    int percent = (int) ((float) (maxDamage - damage) / maxDamage * 100.0f);
                    int color = getDurabilityColor(percent);
                    String text = percent + "%";
                    int textWidth = MC.client3.field_1772.method_1727(text);
                    int textX = itemX + 10 - textWidth / 2;
                    context.method_51433(MC.client3.field_1772, text, textX, 18, color, shadow.getValue());
                }
            } else if (isEditorMode()) {
                context.method_25294(itemX + 2, 0, itemX + 18, 16, 0x22FFFFFF);
            }
            itemX += 20;
        }

        context.method_51448().method_22909();
    }

    private int getDurabilityColor(int percent) {
        float f = Math.max(0.0f, Math.min(1.0f, percent / 100.0f));
        int red = (int) (196.0f + -196.0f * f);
        int green = (int) (0.0f + 227.0f * f);
        return 0xFF000000 | red << 16 | green << 8;
    }
}


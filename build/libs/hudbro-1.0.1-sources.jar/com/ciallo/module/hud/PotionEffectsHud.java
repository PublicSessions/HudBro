package com.ciallo.module.hud;

import com.ciallo.api.Listener3;
import com.ciallo.module.Category;
import com.ciallo.module.Module;
import com.ciallo.setting.BooleanSetting;
import com.ciallo.setting.ColorSetting;
import com.ciallo.setting.NumberSetting;
import com.ciallo.setting.TextSetting;
import com.ciallo.util.MC;

import java.util.Collection;
import net.minecraft.class_1293;
import net.minecraft.class_332;

public class PotionEffectsHud extends AbstractHudModule implements Listener3 {
    private final NumberSetting x = (NumberSetting) this.m28(new NumberSetting("X", 6.0, 0.0, 960.0, 1.0, 1.0));
    private final NumberSetting y = (NumberSetting) this.m28(new NumberSetting("Y", 30.0, 0.0, 463.0, 1.0, 1.0));
    private final BooleanSetting shadow = (BooleanSetting) this.m28(new BooleanSetting("Shadow", true));
    private final ColorSetting backgroundColor = (ColorSetting) this.m28(new ColorSetting("BackgroundColor", 0xDD000000));
    private final ColorSetting textColor = (ColorSetting) this.m28(new ColorSetting("TextColor", 0xFFFFFFFF));
    private final NumberSetting scale = (NumberSetting) this.m28(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.1));
    private final TextSetting durationFormat = (TextSetting) this.m28(new TextSetting("DurationFormat", "mm:ss", "Duration format: mm:ss or ms"));

    public PotionEffectsHud() {
        super("PotionEffects", "Shows active potion effects.", Category.HUD);
        this.setChinese("药水效果");
        this.setChineseDescription("显示药水效果");
    }

    @Override
    public int getX() {
        return x.getInt();
    }

    @Override
    public int getY() {
        return y.getInt();
    }

    @Override
    public int getWidth() {
        return Math.round(120 * scale.getFloat());
    }

    @Override
    public int getHeight() {
        return Math.round(MC.client3.field_1772.field_2000 * scale.getFloat() * 5);
    }

    @Override
    public void setPosition(int x, int y) {
        this.x.setInt(x);
        this.y.setInt(y);
    }

    @Override
    public void render(class_332 context, float partialTicks) {
        if (MC.client3.field_1724 == null) return;

        int posX = getX();
        int posY = getY();
        float s = scale.getFloat();
        Collection<class_1293> effects = MC.client3.field_1724.method_6026();
        int textHeight = (int) (MC.client3.field_1772.field_2000 * s);
        int rowHeight = textHeight + (int) (2 * s);
        int rowWidth = (int) (120 * s);

        context.method_51448().method_22903();
        context.method_51448().method_22904((double)posX, (double)posY, 0.0);

        int currentY = 0;
        for (class_1293 effect : effects) {
            if (!effect.method_5581()) continue;

            int bgColor = backgroundColor.getColor();
            int txtColor = textColor.getColor();

            context.method_25294(0, currentY, rowWidth, currentY + rowHeight, bgColor);

            String name = effect.method_5579().comp_349().method_5560().getString();
            String duration = formatDuration(effect.method_5584());
            context.method_51433(MC.client3.field_1772, name + " " + duration, (int) (2 * s), currentY + (int) (1 * s), txtColor, shadow.getValue());

            currentY += rowHeight;
        }

        context.method_51448().method_22909();
    }

    private String formatDuration(int ticks) {
        String format = durationFormat.getValue().toLowerCase();
        if (format.equals("ms")) {
            return ticks * 50 + "ms";
        }
        int seconds = ticks / 20;
        int minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}


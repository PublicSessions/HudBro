package com.ciallo.util;

import net.minecraft.class_310;

public class MC {
    public static final class_310 client3 = class_310.method_1551();
}

